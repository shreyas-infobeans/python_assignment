
def fun2(n):
    print("fun2",100/n)
