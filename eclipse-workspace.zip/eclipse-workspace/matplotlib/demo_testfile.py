import matplotlib.pyplot as plt
import numpy as np

xpoints  = np.array([2020,2021,2022,2023])
ypoints  = np.array([6.6,8.7,7.0,6.8])

plt.plot(xpoints,ypoints)
plt.show()