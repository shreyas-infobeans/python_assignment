my_toppings = [x for x in input("onions \nLettuce \nTomato \nSelect toppics of your choice ").split()]


sandwitch = int(input("How many sandwitches you want?"))

print(my_toppings)
print("sandwitch price$",sandwitch*5)


