s=input()
print(s)
name = input("Enter your name")
print(name)

lst = [x for x in input("Enter three numbers separated by space:").split()]
print(lst)