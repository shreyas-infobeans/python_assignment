a,b = 10,20
print(a,b,sep="---")

name="john"
marks=78.7

print("name is ",name, " total marks are ",marks)

print("name is %s total marks are %.2f "%(name,marks))

print("name is {} total marks are {} ".format(name,marks))