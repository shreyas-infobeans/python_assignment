'''
Created on Aug 23, 2024

@author: shreyas
'''
def add(x,y):
    return x+y