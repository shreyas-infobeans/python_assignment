def display(fun):
    return "hellp "+fun

def name():
    return "Shreyas"

print(display(name()))