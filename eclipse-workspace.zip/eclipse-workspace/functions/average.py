def average(a,b):
    print("Average is ",(a+b)/2)
    
average(2,3)