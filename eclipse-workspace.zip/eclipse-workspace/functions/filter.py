lst = [10,3,5,34,67,66]

fn = list(filter(lambda x:x%2==0,lst))

print(fn)