from math import *

print(sqrt(8))
print(ceil(8.2))
print(floor(9.6))
print(fabs(-2.2))

print(dir())