lst = [3,4,5]

fn = list(map(lambda x:x*2,lst))

print(fn)
