#import mymath1 as mm
from mymath1 import *
print(add(10,11))