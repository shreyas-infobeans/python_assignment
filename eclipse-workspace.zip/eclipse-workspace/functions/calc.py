def calc(a,b):
    x = a+b
    y = a-b
    return x,y
res = calc(10,20)
print(res)