'''
Created on Aug 23, 2024

@author: shreyas
'''
def add(a,b):
    return a+b

def diff(a,b):
    return a-b