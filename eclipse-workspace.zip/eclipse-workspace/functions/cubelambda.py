def cube(a):
    return a**3
#print(cube(2))

#f = lambda n:n**3

#print(f(2))

""""f = lambda n:"Yes"  if n%2==0  else  "No"

print(f(2))
print(f(3))"""

f = lambda a,b:a+b

print(f(1,2))
