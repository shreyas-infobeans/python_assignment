a=10
b=10

print(a is b)
print(id(a))
print(id(b))