lst = [0,10,"work",78.9]
lst.append(5)
print(lst)
lst.remove("work")
print(max(lst))

lst.remove(0)

del(lst[1])

lst.clear()#clear all elements

lst.insert(3,90) #– insert element in specific position

lst.sort() 

lst.sort(reverse=True)
