s = {10,20,"xyz",10}

print((s))
s.update([88,90])
print((s))

s.remove(10)
print((s))