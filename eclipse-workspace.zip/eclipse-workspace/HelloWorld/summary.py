a = 20
b = 20
print(id(a), id(b))

f = 3.4
f2 = 3.4
print(id(f), id(f2))

c= 5+3j
print(c.real)
print(c.imag)

lst = [1,2,3,4,5]
b = bytes(lst)
print(b)