t1 = (1,2,"shreyas",2)

print(t1)
print(type(t1))

print(t1*3)

print(t1.count(1))

print(t1.index(1))

lst = [1,2,3]
print(type(lst))

tpl = tuple(lst)
print(type(tpl))    