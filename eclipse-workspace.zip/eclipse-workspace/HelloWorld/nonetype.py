def m1():
        a= 10
        
print(m1())