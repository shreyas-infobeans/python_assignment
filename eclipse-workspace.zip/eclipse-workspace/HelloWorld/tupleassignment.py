tpl = (1,2,3,"x","y","z")

print(tpl[0])

print(tpl[2])

print(len(tpl))

if "a" in tpl:
    print("a exists")
else:
    print("a does not exists")    
    

if 3 in tpl:
    print("3 exists")
else:
    print("3 does not exists")      