student_info = {"name":"Shreyas","age":23,"major":"arts"}
#print(student_info)

print(student_info['name'])

print(student_info['age'])

student_info['age'] = 24

print(student_info['age'])

del student_info["major"]

print(student_info)