s= "you are awesome"
print(type(s))
"""print(s*2)
print(s[2])
print(len(s))"""
print(s[::-1])   
#print(s[0:3])
#print(s[-5:-4])
#print(s[0:9:-1])