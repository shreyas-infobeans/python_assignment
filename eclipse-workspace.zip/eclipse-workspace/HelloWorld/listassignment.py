lst = ["India", "Australia", "Europe"]
print(type(lst))

lst.append("shrilanka")
print((lst)[0])

del(lst[1])
print((lst))
lst.insert(0,"USA")
print((lst))