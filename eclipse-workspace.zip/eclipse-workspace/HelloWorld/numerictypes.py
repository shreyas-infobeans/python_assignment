firstName = "shreyas"
lastName = "D"
age = 23
ssn = "ASJPP0"
height = 5.5
weight = 4.5
"""print(type(firstName))
print(type(ssn))
print(type(height))
print(type(age))"""

first = 10
second = 20.54
third = True
fourth = "I am the best"

print(first)
print(second)
print(third)
print(fourth)