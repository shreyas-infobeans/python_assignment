id=1
firstName="Shreyas"
lastName="    Dhokte"
ssn="123-456-6767"
hasInsurance=True
billingAmount="1800"

print(id,firstName,lastName.strip(),ssn[8:len(ssn)],float(billingAmount))