from numpy import *

arr = array([1,2,3])  

#print(arr)

#print(linspace(0,100))

l = logspace(0,10)

#print(arange(1,20))

print(zeros(10))

print(ones(10))