from numpy import *

a1 = arange(3,12)
print(a1)
print(a1[3:7])