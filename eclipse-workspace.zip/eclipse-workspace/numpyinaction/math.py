from numpy import *

a1 = array([1,2,3,4])

a2 = array([10,11,12,13])

print(a1+a2)

print(a1-2)

print(sin(a1))

print(min(a1))

print(mean(a1))