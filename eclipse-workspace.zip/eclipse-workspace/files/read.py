f = open("myfile.txt","r")
s = f.read()
print(s)
f.close