f = open("myfile.txt","w")
s = input("Enter Text:")
f.write(s)
f.close()