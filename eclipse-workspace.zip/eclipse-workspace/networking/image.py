import urllib.request

url = "https://timemaster.creatingwow.in/assets/TM%20logo.svg"

urllib.request.urlretrieve(url, "ib.svg")