import datetime

dt = datetime.datetime.today()
print("Current date {}/{}/{}".format(dt.day,dt.month,dt.year))