s = "-".join(['a','b','c'])
print(s)

st = input("Enter a string")
print(''.join(reversed(st)))