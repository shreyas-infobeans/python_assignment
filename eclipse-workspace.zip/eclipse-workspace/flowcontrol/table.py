num = int(input("Enter a number"))
"""lst = [1,2,3,4,5,6,7,8,9,10]
table = 0

for i in lst:
    table+=num
    print(table)"""
for i in range(1,11):
    print(num,'X',i,'=',i*num)