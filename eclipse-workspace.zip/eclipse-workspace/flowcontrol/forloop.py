for i in range(50,71,2):
    print(i)