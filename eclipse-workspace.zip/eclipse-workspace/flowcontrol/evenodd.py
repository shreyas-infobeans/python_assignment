number = int(input("Please enter a number: "))

if number%2 == 0:
    print("Even number")
else:
    print("Odd Number")    