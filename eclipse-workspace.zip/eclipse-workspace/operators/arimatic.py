a,b = 10,5  

print('Addition:',a+b)

print('Substraction:',a-b)

print('Multi:',a*b)

print('Div:',a/b)

print('Mod:',a%b)

print('Pow:',a**b)

print('Floor Div:',a//b)