a,b,c = [int(x) for x in input("enter three numbers").split()]

average = (a+b+c)/3

print("Average is ",average)