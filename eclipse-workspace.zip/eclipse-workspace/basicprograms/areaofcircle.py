import math
radius = float(input("Enter the radius "))
#pi= 22/7
area = math.pi*radius**2
print(f"Area is: {area:.2f}")