x = 3

match x:
    case 1:
        print("1")
    case 2:
        print("2")
    case 3:
        print("3")