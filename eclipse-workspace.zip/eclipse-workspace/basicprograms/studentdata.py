student_id =  int(input("Enter id "))
student_name =  (input("Enter Name "))
student_marks =  float(input("Enter marks "))

print("ID: ",student_id, "Name: ",student_name," Marks:",student_marks)