import sys
lst = sys.argv
print(int(lst[1]*int(lst[2])))